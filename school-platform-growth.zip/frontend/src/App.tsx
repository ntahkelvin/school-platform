import { useEffect, useState } from "react";
import { api, ApiError, getToken, setToken, type Me } from "./api";
import Login from "./Login";
import Dashboard from "./Dashboard";
import SchoolPage from "./SchoolPage";
import StudentPage from "./StudentPage";
import RegisterPage from "./RegisterPage";
import OrgPage from "./OrgPage";
import BoardView from "./BoardView";
import { ChoosePassword } from "./Logins";
import StaffHome from "./StaffHome";
import StaffRecordPage from "./StaffRecord";
import IdCardsPage from "./IdCards";
import KioskPage from "./Kiosk";
import PassportPage from "./Passport";
import { go, useRoute, type BranchTab } from "./router";
import { cache, isNetworkError } from "./offline";

export default function App() {
  const [me, setMe] = useState<Me | null>(null);
  const [checking, setChecking] = useState(Boolean(getToken()));
  const route = useRoute();

  useEffect(() => {
    if (!getToken()) return;
    api
      .me()
      .then((m) => {
        cache.set("me", m);
        setMe(m);
      })
      .catch((err) => {
        if (err instanceof ApiError && err.status === 401) setToken(null);
        // No internet: carry on as the last person who logged in on this device.
        else if (isNetworkError(err)) setMe(cache.get<Me>("me"));
      })
      .finally(() => setChecking(false));
  }, []);

  function logout() {
    setToken(null);
    cache.set("me", null);
    setMe(null);
    window.location.hash = "";
  }

  // The gate kiosk works without anyone logged in.
  if (route.page === "kiosk") return <KioskPage schoolId={route.school} token={route.token} />;
  if (checking) return <div className="center muted">Loading…</div>;
  if (!me) return <Login onLoggedIn={setMe} />;

  if (me.must_change_password)
    return <ChoosePassword me={me} onLogout={logout} onDone={() => setMe({ ...me, must_change_password: false })} />;

  const common = { me, onLogout: logout };
  // Board members who don't run a school only ever see the read-only board view.
  const isOwner = me.memberships.some((m) => m.role === "owner");
  const isBoard = me.memberships.some((m) => m.role === "board_member");
  const STAFF = ["head", "vice_principal", "it_admin", "bursar", "teacher", "house_parent", "support"];
  const isStaff = me.memberships.some((m) => STAFF.includes(m.role));
  const runs = new Set(me.memberships.filter((m) => ["head", "vice_principal", "it_admin"].includes(m.role)).map((m) => m.school_id));
  if (!isOwner && !isStaff && isBoard) return <BoardView {...common} />;
  if (!isOwner && isStaff) {
    // Staff: their own portal; principals, vice principals and the IT team can also open their school's pages.
    if (route.page === "school" && runs.has(route.id)) return <SchoolPage key={route.id} {...common} schoolId={route.id} tab={route.tab} />;
    if (route.page === "register") return <RegisterPage key={`${route.kind}${route.id}${route.date}`} {...common} kind={route.kind} id={route.id} date={route.date} />;
    if (route.page === "student" && runs.size) return <StudentPage key={route.id} {...common} studentId={route.id} />;
    if (route.page === "board" && isBoard) return <BoardView {...common} />;
    if (route.page === "staff-record") return <StaffRecordPage key={route.id} {...common} schoolId={route.school} userId={route.id} />;
    if (route.page === "staff-cards") return <IdCardsPage key={`${route.school}${route.id}`} {...common} schoolId={route.school} userId={route.id} />;
    if (route.page === "passport") return <PassportPage key={route.id} {...common} schoolId={route.school} userId={route.id} />;
    return <StaffHome {...common} />;
  }
  switch (route.page) {
    case "org":
      return <OrgPage key={route.id} {...common} orgId={route.id} />;
    case "board":
      return <BoardView {...common} />;
    case "school":
      return <SchoolPage key={route.id} {...common} schoolId={route.id} tab={route.tab} />;
    case "branch":
      // Old links to a "branch": send them to its school's page instead.
      return <BranchRedirect branchId={route.id} tab={route.tab} />;
    case "register":
      return <RegisterPage key={`${route.kind}${route.id}${route.date}`} {...common} kind={route.kind} id={route.id} date={route.date} />;
    case "student":
      return <StudentPage key={route.id} {...common} studentId={route.id} />;
    case "staff":
      return <StaffHome {...common} />;
    case "staff-record":
      return <StaffRecordPage key={route.id} {...common} schoolId={route.school} userId={route.id} />;
    case "staff-cards":
      return <IdCardsPage key={`${route.school}${route.id}`} {...common} schoolId={route.school} userId={route.id} />;
    case "passport":
      return <PassportPage key={route.id} {...common} schoolId={route.school} userId={route.id} />;
    default:
      return <Dashboard {...common} />;
  }
}

function BranchRedirect({ branchId, tab }: { branchId: string; tab: BranchTab }) {
  useEffect(() => {
    api.branch(branchId)
      .then((b) => go({ page: "school", id: b.school_id, tab }))
      .catch(() => go({ page: "home" }));
  }, [branchId, tab]);
  return <div className="center muted">Loading…</div>;
}
